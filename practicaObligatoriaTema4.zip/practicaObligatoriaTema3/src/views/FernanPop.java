package views;

import models.Producto;
import models.RegistroHistorico;
import models.Usuario;
import utils.Utils;
import utils.Comunicaciones;

import java.time.LocalDate;
import java.util.Scanner;

public class FernanPop {
    //Variables estáticas para que todas las funciones las vean
    public static Scanner scanner = new Scanner(System.in);
    public static Usuario usuario1 = new Usuario("Carlos", "carlos.barroso@fernando3martos.com", "1234");
    public static Usuario usuario2 = new Usuario("Ana", "ana@fernando3martos.com", "5678");
    public static Usuario usuarioNuevo = null; //Para el registro de un tercer usuario

    public static void main(String[] args) {
        //Los usuarios iniciales se marcan como validados para las pruebas
        usuario1.setValidado(true);
        usuario2.setValidado(true);

        int opcionEntrada = 0;
        do {
            try {
                mostrarMenuInicial();
                opcionEntrada = Integer.parseInt(scanner.nextLine());

                if (opcionEntrada == 1) {
                    Usuario usuarioLogueado = realizarLogin();
                    if (usuarioLogueado != null) {
                        iniciarMenuPrincipal(usuarioLogueado);
                    }
                } else if (opcionEntrada == 2) {
                    realizarRegistro();
                }

            } catch (NumberFormatException e) {
                System.out.println("Error: Por favor, introduzca un número válido para la opción.");
            }
        } while (opcionEntrada != 9);
    }

    private static void mostrarMenuInicial() {
        System.out.println("\n--- BIENVENIDO A FERNANPOP ---");
        System.out.println("1. Iniciar Sesión");
        System.out.println("2. Registrarse");
        System.out.println("9. Salir del programa");
        System.out.print("Seleccione una opción: ");
    }

    private static Usuario realizarLogin() {
        System.out.print("Introduzca email: ");
        String emailIntroducido = scanner.nextLine();
        System.out.print("Introduzca clave: ");
        String claveIntroducida = scanner.nextLine();

        Usuario usuarioEncontrado = buscarUsuarioPorEmail(emailIntroducido);

        if (usuarioEncontrado != null && usuarioEncontrado.getClave().equals(claveIntroducida)) {
            if (!usuarioEncontrado.isValidado()) {
                System.out.println("Error: Su cuenta no ha sido activada mediante el token de seguridad.");
                validarTokenSeguridad(usuarioEncontrado);
                return null;
            }
            System.out.println("Acceso concedido. Bienvenido " + usuarioEncontrado.getNombre());
            return usuarioEncontrado;
        } else {
            System.out.println("Error: Credenciales de acceso incorrectas.");
            return null;
        }
    }

    private static void realizarRegistro() {
        System.out.println("\n--- FORMULARIO DE REGISTRO ---");
        System.out.print("Nombre completo: ");
        String nombreNuevo = scanner.nextLine();
        System.out.print("Correo electrónico: ");
        String emailNuevo = scanner.nextLine();

        //Comprobación de email repetido
        if (buscarUsuarioPorEmail(emailNuevo) != null) {
            System.out.println("Error: Ya existe una cuenta asociada a este correo electrónico.");
            return;
        }

        System.out.print("Clave de acceso: ");
        String claveNueva = scanner.nextLine();

        //Creamos el nuevo usuario
        usuarioNuevo = new Usuario(nombreNuevo, emailNuevo, claveNueva);

        //Generamos un token aleatorio de 4 dígitos
        String tokenGenerado = String.valueOf((int) (Math.random() * 9000) + 1000);
        usuarioNuevo.setToken(tokenGenerado);

        //Enviamos el token por correo usando la clase Comunicaciones
        System.out.println("Enviando código de activación...");
        Comunicaciones.enviarConGMail(emailNuevo, "Validación de cuenta FernanPop", "Su código de activación es: " + tokenGenerado);

        validarTokenSeguridad(usuarioNuevo);
    }

    private static void validarTokenSeguridad(Usuario usuarioAValidar) {
        System.out.print("Introduzca el token de seguridad recibido en su correo: ");
        String tokenIntroducido = scanner.nextLine();

        if (usuarioAValidar.getToken().equals(tokenIntroducido)) {
            usuarioAValidar.setValidado(true);
            System.out.println("¡Cuenta activada con éxito! Ya puede iniciar sesión.");
        } else {
            System.out.println("Error: El token introducido es incorrecto. La cuenta sigue inactiva.");
        }
    }

    private static void iniciarMenuPrincipal(Usuario usuarioActual) {
        int opcionSeleccionada = 0;
        do {
            imprimirOpcionesMenuPrincipal();
            try {
                opcionSeleccionada = Integer.parseInt(scanner.nextLine());
                procesarAccionMenu(opcionSeleccionada, usuarioActual);
            } catch (NumberFormatException e) {
                System.out.println("Error: Formato de número no válido.");
            }
        } while (opcionSeleccionada != 9);
    }

    private static void imprimirOpcionesMenuPrincipal() {
        System.out.println("""
                \nMenú de Usuario FernanPop
                1. Mostrar mi perfil
                2. Cambiar mi nombre
                3. Ver mis artículos en venta
                4. Publicar un nuevo producto
                5. Ver catálogo global de la aplicación
                6. Consultar histórico de ventas
                7. Consultar histórico de compras
                8. Cerrar una venta o retirar producto
                9. Cerrar sesión
                Introduzca la opción deseada:""");
    }

    private static void procesarAccionMenu(int opcion, Usuario usuarioActual) {
        switch (opcion) {
            case 1 -> System.out.println(usuarioActual.toString());
            case 2 -> {
                System.out.print("Introduzca su nuevo nombre: ");
                usuarioActual.setNombre(scanner.nextLine());
                System.out.println("Datos actualizados correctamente.");
            }
            case 3 -> mostrarArticulosDelUsuario(usuarioActual);
            case 4 -> publicarNuevoArticulo(usuarioActual);
            case 5 -> mostrarCatalogoCompleto();
            case 6 -> mostrarDetalleHistorico(usuarioActual.getHistoricoVenta(), "VENTAS");
            case 7 -> mostrarDetalleHistorico(usuarioActual.getHistoricoCompra(), "COMPRAS");
            case 8 -> gestionarCierreDeVenta(usuarioActual);
            case 9 -> System.out.println("Cerrando sesión de usuario...");
            default -> System.out.println("Opción no reconocida.");
        }
        if (opcion != 9) {
            Utils.pulsaParaContinuar();
            Utils.limpiaPantalla();
        }
    }

    private static void publicarNuevoArticulo(Usuario usuarioActual) {
        try {
            System.out.print("Nombre del producto: ");
            String nombreArticulo = scanner.nextLine();
            System.out.print("Precio de venta: ");
            double precioArticulo = Double.parseDouble(scanner.nextLine());
            System.out.print("Descripción detallada: ");
            String descripcionArticulo = scanner.nextLine();

            //El id se genera aleatoriamente dentro del constructor de Producto
            Producto nuevoProducto = new Producto(nombreArticulo, descripcionArticulo, precioArticulo);

            //Comprobar si el ID asignado ya existía
            while (comprobarSiIdEstaRepetido(nuevoProducto.getId())) {
                //Si el id ya existe en algún usuario, generamos uno nuevo y lo asignamos
                int nuevoIdAleatorio = (int) (Math.random() * 100000) + 1;
                nuevoProducto.setId(nuevoIdAleatorio);
            }

            if (usuarioActual.ponerALaVenta(nuevoProducto)) {
                System.out.println("¡Producto publicado con ID: " + nuevoProducto.getId() + "!");

                //Notificaciones
                Comunicaciones.enviarConGMail(usuarioActual.getEmail(), "Confirmación de publicación", "Has subido el producto: " + nombreArticulo);
                Comunicaciones.enviaMensajeTelegram("Notificación Admin: El usuario " + usuarioActual.getNombre() + " ha publicado " + nombreArticulo);
            } else {
                System.out.println("Error: Ha alcanzado el límite máximo de productos en venta (2).");
            }
        } catch (NumberFormatException e) {
            System.out.println("Error: El precio debe ser un valor numérico válido.");
        }
    }

    private static void gestionarCierreDeVenta(Usuario usuarioVendedor) {
        try {
            System.out.print("¿Qué hueco desea gestionar (1 o 2)?: ");
            int numeroHueco = Integer.parseInt(scanner.nextLine());
            System.out.print("¿Desea registrar una Venta (V) o una Retirada (Q)?: ");
            String seleccionAccion = scanner.nextLine().toUpperCase();

            if (seleccionAccion.equals("V")) {
                Usuario usuarioComprador = identificarOtroUsuario(usuarioVendedor);

                if (usuarioComprador == null) {
                    System.out.println("Error: No hay un segundo usuario disponible para realizar la transacción.");
                    return;
                }

                System.out.print("Introduzca el precio final acordado: ");
                double precioFinalTransaccion = Double.parseDouble(scanner.nextLine());

                RegistroHistorico registroDeVenta = new RegistroHistorico(precioFinalTransaccion, usuarioComprador.getEmail(), 5, "Operación finalizada", LocalDate.now());
                RegistroHistorico registroDeCompra = new RegistroHistorico(precioFinalTransaccion, usuarioVendedor.getEmail(), 5, "Operación finalizada", LocalDate.now());

                if (usuarioVendedor.registrarVenta(registroDeVenta) && usuarioComprador.registrarCompra(registroDeCompra)) {
                    vaciarHuecoProducto(usuarioVendedor, numeroHueco);
                    System.out.println("Venta cerrada y notificada con éxito.");

                    //Notificaciones de transacción
                    Comunicaciones.enviarConGMail(usuarioVendedor.getEmail(), "Venta realizada", "Se ha registrado la venta de su artículo.");
                    Comunicaciones.enviaMensajeTelegram("Notificación Admin: Transacción completada entre " + usuarioVendedor.getNombre() + " y " + usuarioComprador.getNombre());
                } else {
                    System.out.println("Error: No se puede registrar en el histórico (límite alcanzado).");
                }
            } else {
                vaciarHuecoProducto(usuarioVendedor, numeroHueco);
                System.out.println("El producto ha sido retirado.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Error: Introduzca datos numéricos válidos.");
        }
    }

    private static boolean comprobarSiIdEstaRepetido(int idABuscar) {
        // Comprobar en usuario 1
        if (usuario1.getProducto1() != null && usuario1.getProducto1().getId() == idABuscar) return true;
        if (usuario1.getProducto2() != null && usuario1.getProducto2().getId() == idABuscar) return true;

        // Comprobar en usuario 2
        if (usuario2.getProducto1() != null && usuario2.getProducto1().getId() == idABuscar) return true;
        if (usuario2.getProducto2() != null && usuario2.getProducto2().getId() == idABuscar) return true;

        // Comprobar en usuario nuevo (si existe)
        if (usuarioNuevo != null) {
            if (usuarioNuevo.getProducto1() != null && usuarioNuevo.getProducto1().getId() == idABuscar) return true;
            if (usuarioNuevo.getProducto2() != null && usuarioNuevo.getProducto2().getId() == idABuscar) return true;
        }
        return false;
    }

    private static Usuario buscarUsuarioPorEmail(String emailABuscar) {
        if (usuario1.getEmail().equalsIgnoreCase(emailABuscar)) return usuario1;
        if (usuario2.getEmail().equalsIgnoreCase(emailABuscar)) return usuario2;
        if (usuarioNuevo != null && usuarioNuevo.getEmail().equalsIgnoreCase(emailABuscar)) return usuarioNuevo;
        return null;
    }

    private static Usuario identificarOtroUsuario(Usuario usuarioReferencia) {
        if (usuarioReferencia == usuario1) return usuario2;
        if (usuarioReferencia == usuario2) return usuario1;
        return null;
    }

    private static void vaciarHuecoProducto(Usuario usuarioDestino, int hueco) {
        if (hueco == 1) usuarioDestino.setProducto1(null);
        else usuarioDestino.setProducto2(null);
    }

    private static void mostrarArticulosDelUsuario(Usuario usuarioAConsultar) {
        System.out.println("Artículos en venta de " + usuarioAConsultar.getNombre() + ":");
        if (usuarioAConsultar.getProducto1() == null && usuarioAConsultar.getProducto2() == null) {
            System.out.println("- Sin artículos publicados actualmente.");
        } else {
            if (usuarioAConsultar.getProducto1() != null) System.out.println("1. " + usuarioAConsultar.getProducto1());
            if (usuarioAConsultar.getProducto2() != null) System.out.println("2. " + usuarioAConsultar.getProducto2());
        }
    }

    private static void mostrarCatalogoCompleto() {
        System.out.println("--- CATÁLOGO GLOBAL DE FERNANPOP ---");
        mostrarArticulosDelUsuario(usuario1);
        System.out.println("------------------------------------");
        mostrarArticulosDelUsuario(usuario2);
        if (usuarioNuevo != null) {
            System.out.println("------------------------------------");
            mostrarArticulosDelUsuario(usuarioNuevo);
        }
    }

    private static void mostrarDetalleHistorico(RegistroHistorico registro, String tipo) {
        if (registro != null) {
            System.out.println("HISTÓRICO DE " + tipo + ":");
            System.out.println(registro.toString());
        } else {
            System.out.println("No existen registros previos de " + tipo + ".");
        }
    }
}