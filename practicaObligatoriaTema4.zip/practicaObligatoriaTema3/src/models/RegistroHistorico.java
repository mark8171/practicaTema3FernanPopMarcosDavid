package models;

import java.time.LocalDate;

public class RegistroHistorico {
    //Atributos privados
    private double precioFinal;
    private String emailContraparte;
    private int puntuacion;
    private String comentario;
    private LocalDate fecha;

    //Constructor
    public RegistroHistorico(double precioFinal, String emailContraparte, int puntuacion, String comentario, LocalDate fecha) {
        this.precioFinal = precioFinal;
        this.emailContraparte = emailContraparte;
        this.puntuacion = puntuacion;
        this.comentario = comentario;
        this.fecha = fecha;
    }

    //Getters and Setters
    public double getPrecioFinal() {
        return precioFinal;
    }

    public void setPrecioFinal(double precioFinal) {
        this.precioFinal = precioFinal;
    }

    public String getEmailContraparte() {
        return emailContraparte;
    }

    public void setEmailContraparte(String emailContraparte) {
        this.emailContraparte = emailContraparte;
    }

    public int getPuntuacion() {
        return puntuacion;
    }

    public void setPuntuacion(int puntuacion) {
        this.puntuacion = puntuacion;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    //Otros métodos
    //Metodo que valida la puntuación
    private int validarPuntuacion(int puntuacion){
        if (puntuacion < 1){
            return 1;
        } else if (puntuacion > 5) {
            return 5;
        } else {
            return puntuacion;
        }
    }

    //toString
    @Override
    public String toString() {
        return "---------- DETALLE DE LA OPERACIÓN ----------\n" +
                " FECHA:        " + fecha + "\n" +
                " CONTACTO:     " + emailContraparte + "\n" +
                " PRECIO FINAL: " + precioFinal + " €\n" +
                " PUNTUACIÓN:   " + puntuacion + "/5\n" +
                " COMENTARIO:   " + comentario + "\n" +
                "---------------------------------------------";
    }
}
