package models;

public class Producto {
    //Atributos privados
    private int id;
    private String nombre;
    private String descripcion;
    private double precio;
    private boolean enVenta;

    //Constructor
    public Producto(String nombre, String descripcion, double precio) {
        this.id = (int) (Math.random() * 100000) + 1;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.enVenta = enVenta;
    }

    //Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public boolean isEnVenta() {
        return enVenta;
    }

    public void setEnVenta(boolean enVenta) {
        this.enVenta = enVenta;
    }

    //Otros métodos
    //Metodo que cambia el estado del producto para que no aparezca disponible
    public void quitarDeLaVenta(){
        this.enVenta = false;
    }

    //Metodo que permite volver a poner a la venta un producto
    public void ponerALaVenta(){
        this.enVenta = true;
    }

    //toString
    @Override
    public String toString() {
        String estado = enVenta ? "DISPONIBLE" : "RETIRADO/VENDIDO";
        return "---------- DETALLE DEL PRODUCTO ----------\n" +
                " ID:          " + id + "\n" +
                " NOMBRE:      " + nombre + "\n" +
                " DESCRIPCIÓN: " + descripcion + "\n" +
                " PRECIO:      " + precio + "\n" +
                " ESTADO:      " + estado + "\n" +
                "------------------------------------------";
    }
}
