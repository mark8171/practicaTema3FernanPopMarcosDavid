package utils;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.Properties;

public class Comunicaciones {
    public static boolean enviaMensajeTelegram(String mensaje){
        String direccion;
        String fijo="https://api.telegram.org/bot7794985293:AAGa6FeuHg-gPz4wFTF4OIeq65Clw0LIKLI/sendMessage?chat_id=5882350694&text=";
        direccion=fijo+mensaje;
        URL url;
        boolean dev;
        dev=false;
        try{
            url = new URL(direccion);
            URLConnection con = url.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            dev=true;
        }catch (IOException e){
            System.out.println(e.getMessage());
        }
        return dev;
    }

    public static void enviarConGMail(String destinatario, String asunto, String cuerpo) {
        String remitente = "marcosvalientemoya@gmail.com";
        // 2. IMPORTANTE: Contraseña de aplicación SIN espacios
        String clave = "xrrrqhuowznctoxs";

        Properties props = System.getProperties();
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.user", remitente);
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.port", "587");

        // 3. Usamos getInstance en lugar de getDefaultInstance para mayor fiabilidad
        Session session = Session.getInstance(props);

        try {
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(remitente));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
            message.setSubject(asunto);
            message.setContent(cuerpo, "text/html; charset=utf-8");

            Transport transport = session.getTransport("smtp");

            // 4. Aquí es donde ocurre la autenticación real
            transport.connect("smtp.gmail.com", remitente, clave);
            transport.sendMessage(message, message.getAllRecipients());
            transport.close();

            System.out.println("Correo enviado con éxito.");
        } catch (MessagingException me) {
            me.printStackTrace();
        }
    }
}
