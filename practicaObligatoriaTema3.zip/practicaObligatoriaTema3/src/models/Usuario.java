package models;

public class Usuario {
    //Atributos privados
    private String nombre;
    private String email;
    private String clave;

    //Capacidad para poner 2 productos a la venta
    private Producto producto1;
    private Producto producto2;

    //Capacidad para una venta y una compra en el histórico
    private RegistroHistorico historicoVenta;
    private RegistroHistorico historicoCompra;

    //Constructor
    public Usuario(String nombre, String email, String clave) {
        this.nombre = nombre;
        this.email = email;
        this.clave = clave;
        this.producto1 = null;
        this.producto2 = null;
        this.historicoVenta = null;
        this.historicoCompra = null;
    }

    //Getters and Setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public Producto getProducto1() {
        return producto1;
    }

    public void setProducto1(Producto producto1) {
        this.producto1 = producto1;
    }

    public Producto getProducto2() {
        return producto2;
    }

    public void setProducto2(Producto producto2) {
        this.producto2 = producto2;
    }

    public RegistroHistorico getHistoricoVenta() {
        return historicoVenta;
    }

    public void setHistoricoVenta(RegistroHistorico historicoVenta) {
        this.historicoVenta = historicoVenta;
    }

    public RegistroHistorico getHistoricoCompra() {
        return historicoCompra;
    }

    public void setHistoricoCompra(RegistroHistorico historicoCompra) {
        this.historicoCompra = historicoCompra;
    }

    //Otros métodos
    //Metodo que añade a la venta un producto nuevo
    public boolean ponerALaVenta(Producto productoNuevo){
        if (this.producto1 == null) {
            this.producto1 = productoNuevo;
            return true;
        } else if (this.producto2 == null) {
            this.producto2 = productoNuevo;
            return true;
        }
        return false;
    }

    //Metodo que intenta registrar una venta
    public boolean registrarVenta(RegistroHistorico registroVenta){
        if (this.historicoVenta == null) {
            this.historicoVenta = registroVenta;
            return true;
        }
        return false;
    }

    //Metodo que intenta registrar una compra
    public boolean registrarCompra(RegistroHistorico registroCompra){
        if (this.historicoCompra == null) {
            this.historicoCompra = registroCompra;
            return true;
        }
        return false;
    }

    //toString
    @Override
    public String toString() {
        return "====================================\n" +
                "       PERFIL DE USUARIO            \n" +
                "====================================\n" +
                " Nombre: " + nombre + "\n" +
                " Email:  " + email + "\n" +
                "------------------------------------";
    }
}
