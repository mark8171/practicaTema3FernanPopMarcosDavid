package views;

import models.Producto;
import models.RegistroHistorico;
import models.Usuario;

import utils.Utils;

import javax.swing.*;
import java.time.LocalDate;
import java.util.Scanner;

public class FernanPop {
    static void main(String[] args) {
        var s = new Scanner(System.in);

        //Inicialización de los usuarios permitidos
        Usuario usuario1 = new Usuario("Carlos", "carlos.barroso@fernando3martos.com", "1234");
        Usuario usuario2 = new Usuario("Ana", "ana@fernando3martos.com", "5678");
        Usuario usuarioActual = null;
        Usuario otroUsuario = null;

        //Login
        System.out.println("""
                Bienvenido al programa FernanPop
                Compra y vende tus artículos en nuestro Centro
                ==============================================""");

        //Comprobación y validación de datos del usuario
        while (usuarioActual == null) {
            System.out.print("Introduzca email: ");
            String email = s.nextLine();
            System.out.print("Introduzca clave: ");
            String clave = s.nextLine();

            if (usuario1.getEmail().equals(email) && usuario1.getClave().equals(clave)) {
                usuarioActual = usuario1;
                otroUsuario = usuario2;
            } else if (usuario2.getEmail().equals(email) && usuario2.getClave().equals(clave)) {
                usuarioActual = usuario2;
                otroUsuario = usuario1;
            } else {
                System.out.println("Email o clave incorrectos.");
            }
        }
        System.out.println("Bienvenido " + usuarioActual.getNombre() + "\n");

        int op = 0;
        do {
            //Menú de usuario
            System.out.println("""
                    Menú de Usuario
                    1. Mostrar mi perfil de usuario
                    2. Cambiar mis datos personales
                    3. Ver mis productos de venta
                    4. Poner a la venta un nuevo producto
                    5. Ver todos los productos a la venta de la aplicación
                    6. Ver mi histórico de ventas
                    7. Ver mi histórico de compras
                    8. Cerrar la venta de un producto o quitarlo de la venta
                    9. Salir
                    Introduzca la opción deseada: """);
            op = Integer.parseInt(s.nextLine());

            switch (op) {
                case 1://Mostrar perfil de usuario
                    System.out.println(usuarioActual.toString());
                    Utils.pulsaParaContinuar();
                    Utils.limpiaPantalla();
                    break;

                case 2://Cambiar datos personales
                    System.out.println("Introduce nuevo nombre: ");
                    usuarioActual.setNombre(s.nextLine());
                    System.out.println("Datos actualizados");
                    Utils.pulsaParaContinuar();
                    Utils.limpiaPantalla();
                    break;

                case 3://Ver mis productos en venta
                    System.out.println("Tus productos:");
                    if (usuarioActual.getProducto1() != null) System.out.println("1. " + usuarioActual.getProducto1());
                    if (usuarioActual.getProducto2() != null) System.out.println("2. " + usuarioActual.getProducto2());
                    if (usuarioActual.getProducto1() == null && usuarioActual.getProducto2() == null) System.out.println("No tienes nada en venta.");
                    Utils.pulsaParaContinuar();
                    Utils.limpiaPantalla();
                    break;

                case 4://Poner un producto a la venta
                    System.out.println("Nombre: ");
                    String nombreProducto = s.nextLine();
                    System.out.println("Precio: ");
                    double precioProducto = Double.parseDouble(s.nextLine());
                    System.out.println("Descripción: ");
                    String descripcionProducto = s.nextLine();
                    if (usuarioActual.ponerALaVenta(new Producto(nombreProducto, descripcionProducto, precioProducto))){
                        System.out.println("¡Producto añadido!");
                    }else {
                        System.out.println("No se puede realizar la operación: límite de productos alcanzado");
                    }
                    Utils.pulsaParaContinuar();
                    Utils.limpiaPantalla();
                    break;

                case 5://Ver todos los productos de la aplicación
                    System.out.println("Productos de la aplicación: ");
                    if (usuario1.getProducto1() != null) System.out.println(usuario1.getProducto1());
                    if (usuario1.getProducto2() != null) System.out.println(usuario1.getProducto2());
                    if (usuario2.getProducto1() != null) System.out.println(usuario2.getProducto1());
                    if (usuario2.getProducto2() != null) System.out.println(usuario2.getProducto2());
                    Utils.pulsaParaContinuar();
                    Utils.limpiaPantalla();
                    break;

                case 6://Ver histórico de ventas
                    if (usuarioActual.getHistoricoVenta() != null) System.out.println(usuarioActual.getHistoricoVenta());
                    else System.out.println("Sin histórico de ventas");
                    Utils.pulsaParaContinuar();
                    Utils.limpiaPantalla();
                    break;

                case 7://Ver histórico de compras
                    if (usuarioActual.getHistoricoCompra() != null) System.out.println(usuarioActual.getHistoricoCompra());
                    else System.out.println("Sin histórico de compras.");
                    Utils.pulsaParaContinuar();
                    Utils.limpiaPantalla();
                    break;

                case 8://Cerrar o quitar una venta de la aplicación
                    System.out.print("¿Qué hueco liberar (1 o 2)?: ");
                    int hueco = Integer.parseInt(s.nextLine());
                    System.out.print("¿Es venta (V) o retiro (Q)?: ");
                    String seleccion = s.nextLine().toUpperCase();

                    if (seleccion.equals("V")) {
                        // Verificación de seguridad para evitar el NullPointerException
                        if (otroUsuario == null) {
                            System.out.println("Error: No se reconoce al comprador.");
                        } else {
                            System.out.print("Precio final: ");
                            double precioFinal = Double.parseDouble(s.nextLine());

                            LocalDate FechaHoy = LocalDate.now();

                            //Creamos los registros
                            RegistroHistorico registroVenta = new RegistroHistorico(precioFinal, otroUsuario.getEmail(), 5, "Vendido", FechaHoy);
                            RegistroHistorico registroCompra = new RegistroHistorico(precioFinal, usuarioActual.getEmail(), 5, "Comprado", FechaHoy);

                            if (usuarioActual.registrarVenta(registroVenta) && otroUsuario.registrarCompra(registroCompra)) {
                                //Liberar el producto vendido del inventario
                                if (hueco == 1) usuarioActual.setProducto1(null);
                                else usuarioActual.setProducto2(null);
                                System.out.println("Venta registrada con éxito.");
                            } else {
                                System.out.println("No se puede realizar la operación: Histórico lleno.");
                            }
                        }
                    } else {
                        //Retirar el producto
                        if (hueco == 1) usuarioActual.setProducto1(null);
                        else usuarioActual.setProducto2(null);
                        System.out.println("Producto retirado.");
                    }
                    Utils.pulsaParaContinuar();
                    Utils.limpiaPantalla();
                    break;

                case 9://Salir de la aplicación
                    System.out.println("Saliendo de FernanPop...");
                    break;
            }

        }while (op != 9);
    }
}
