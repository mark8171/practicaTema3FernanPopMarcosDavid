package utils;

import java.util.Scanner;

public class Utils {
    public static void pulsaParaContinuar(){
        var s = new Scanner(System.in);
        System.out.println("Pulsa una tecla para continuar...");
        s.nextLine();
    }

    public static void limpiaPantalla(){
        for (int i = 0; i < 100; i++) {
            System.out.println();
        }
    }
}
